Dethink Components accessibility snapshot
Tested source: 9807e770dd378b80af287cd98ae3d1cc8f35b7b3
Open with: npx playwright show-report <this-directory>

The HTML report viewer is provided by Playwright; its license and notices accompany this archive. Full scan attachments retain incomplete checks requiring human review. This report is automated evidence, not WCAG certification or screen-reader testing.
